import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppComponent } from './app.component';

// route
import { RouterModule,Routes, Router, ActivatedRoute } from "@angular/router";


// service
import { CustomerService } from './customer.service';
import { MenuService } from './menu.service';

// self create module
import { MaterialModule } from './material.module';
import { RouteModule } from './route/route.module';

//self create component
import { DemoComponent } from './demo/demo.component';
import { HomeComponent } from './home/home.component';
import { MenuComponent } from './menu/menu.component';
import { MainComponent } from './main/main.component';
import { MenuDynamicComponent } from './menu-dynamic/menu-dynamic.component';
import { SideNavComponent } from './side-nav/side-nav.component';
import { RouteComponent } from './route/route.component';
import { SearchComponent } from './search/search.component';



export const routes: Routes = [
  { path: 'demo', component: DemoComponent },
  { path: 'search', component: SearchComponent }
];


@NgModule({
  declarations: [
    AppComponent,
    DemoComponent,
    HomeComponent,
    MenuComponent,
    MainComponent,
    MenuDynamicComponent,
    SideNavComponent,
    RouteComponent,
    SearchComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    MaterialModule,
    
    RouterModule.forRoot(routes)


  ],
  providers: [CustomerService,MenuService],
  bootstrap: [AppComponent]
})





export class AppModule { }
