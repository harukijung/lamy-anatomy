export interface Menu{
    label:number,
    url:string;
    submenu:Menu[];

}