import { Component, OnInit } from '@angular/core';
import { DemoComponent } from '../demo/demo.component';
import { MenuComponent } from '../menu/menu.component';
import { SearchComponent } from '../search/search.component';
import { Routes, Router, ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-route',
  templateUrl: './route.component.html',
  styleUrls: ['./route.component.css']
})


export class RouteComponent implements OnInit {

 

  constructor() { 

    const routes: Routes = [
      { path: 'demo', component: DemoComponent },
      { path: 'search', component: SearchComponent }
    ];
  }

  ngOnInit() {
  }

}
