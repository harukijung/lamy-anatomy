import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule,Routes, Router, ActivatedRoute } from "@angular/router";

import { DemoComponent } from '../demo/demo.component';
import { MenuComponent } from '../menu/menu.component';
import { SearchComponent } from '../search/search.component';




@NgModule({
  imports: [
    CommonModule
  ],
  declarations: []
})
export class RouteModule { }


