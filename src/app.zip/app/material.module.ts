import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule, MatButtonModule, 
         MatInputModule,MatMenuModule,
         MatSidenavModule } from '@angular/material';

@NgModule({
  imports: [
    CommonModule,
    MatTableModule,
    MatButtonModule,
    MatInputModule,
    MatMenuModule,
    MatSidenavModule
  ],
  exports: [MatTableModule,MatButtonModule,MatInputModule,MatMenuModule,MatSidenavModule],
  declarations:[]
})
export class MaterialModule { }
