export interface Customer{
    id:number,
    firstname:string;
    lastname:string;
    email:string
}